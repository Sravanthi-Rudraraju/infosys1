package com.zosh.domain;

public enum WithdrawalStatus {
    PENDING,
    SUCCESS,
    DECLINE
}
